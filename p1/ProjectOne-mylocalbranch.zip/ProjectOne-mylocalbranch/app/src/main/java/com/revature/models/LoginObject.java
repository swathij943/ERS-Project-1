package com.revature.models;

public class LoginObject {
    public String username;
    public String password;
}
