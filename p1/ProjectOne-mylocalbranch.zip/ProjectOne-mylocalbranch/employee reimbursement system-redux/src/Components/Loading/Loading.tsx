import React from 'react';

export const Loading:React.FC = () => {

    return <h1>Loading content</h1>

}